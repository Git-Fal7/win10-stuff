Add-Type -AssemblyName System.Windows.Forms
[System.Windows.Forms.Application]::EnableVisualStyles()

$ErrorActionPreference = 'SilentlyContinue'
$wshell = New-Object -ComObject Wscript.Shell
$Button = [System.Windows.MessageBoxButton]::YesNoCancel
$ErrorIco = [System.Windows.MessageBoxImage]::Error
If (!([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]'Administrator')) {
	Start-Process powershell.exe "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs
	Exit
}

# GUI Specs
Write-Host "ToolzFoolz"

$Form                            = New-Object system.Windows.Forms.Form
$Form.ClientSize                 = New-Object System.Drawing.Point(200,150)
$Form.text                       = "Script by Git-Fal7/Asterisks"
$Form.StartPosition              = "CenterScreen"
$Form.TopMost                    = $false
$Form.BackColor                  = [System.Drawing.ColorTranslator]::FromHtml("#12181c")
$Form.AutoScaleDimensions     = '192, 192'
$Form.AutoScaleMode           = "Dpi"
$Form.AutoSize                = $True
$Form.ClientSize              = '200, 150'
$Form.FormBorderStyle         = 'FixedSingle'

$Panel1                          = New-Object system.Windows.Forms.Panel
$Panel1.height                   = 200
$Panel1.width                    = 220
$Panel1.location                 = New-Object System.Drawing.Point(6,54)

$ELabel                          = New-Object system.Windows.Forms.Label
$ELabel.text                     = "Enable"
$ELabel.AutoSize                 = $true
$ELabel.width                    = 230
$ELabel.height                   = 25
$ELabel.location                 = New-Object System.Drawing.Point(76,11)
$ELabel.Font                     = New-Object System.Drawing.Font('Microsoft Sans Serif',24)
$ELabel.ForeColor				 = [System.Drawing.ColorTranslator]::FromHtml("#FFF")

$EServices                     = New-Object system.Windows.Forms.Button
$EServices.text                = "Enable Services"
$EServices.width               = 211
$EServices.height              = 30
$EServices.location            = New-Object System.Drawing.Point(4,26)
$EServices.Font                = New-Object System.Drawing.Font('Microsoft Sans Serif',12)
$EServices.BackColor           = [System.Drawing.ColorTranslator]::FromHtml("#ccc")

$EUWP                       = New-Object system.Windows.Forms.Button
$EUWP.text                  = "Enable UWP Services"
$EUWP.width                 = 211
$EUWP.height                = 30
$EUWP.location              = New-Object System.Drawing.Point(4,60)
$EUWP.Font                  = New-Object System.Drawing.Font('Microsoft Sans Serif',12)
$EUWP.BackColor           = [System.Drawing.ColorTranslator]::FromHtml("#ccc")

$EUpdates                           = New-Object system.Windows.Forms.Button
$EUpdates.text                      = "Enable Updates"
$EUpdates.width                     = 212
$EUpdates.height                    = 30
$EUpdates.location                  = New-Object System.Drawing.Point(3,94)
$EUpdates.Font                      = New-Object System.Drawing.Font('Microsoft Sans Serif',12)
$EUpdates.BackColor           = [System.Drawing.ColorTranslator]::FromHtml("#ccc")

$Panel2                          = New-Object system.Windows.Forms.Panel
$Panel2.height                   = 200
$Panel2.width                    = 220
$Panel2.location                 = New-Object System.Drawing.Point(239,54)

$DLabel                          = New-Object system.Windows.Forms.Label
$DLabel.text                     = "Disable"
$DLabel.AutoSize                 = $true
$DLabel.width                    = 230
$DLabel.height                   = 25
$DLabel.location                 = New-Object System.Drawing.Point(230,12)
$DLabel.Font                     = New-Object System.Drawing.Font('Microsoft Sans Serif',24)
$DLabel.ForeColor           = [System.Drawing.ColorTranslator]::FromHtml("#FFF")

$DServices                 = New-Object system.Windows.Forms.Button
$DServices.text            = "Disable Services"
$DServices.width           = 204
$DServices.height          = 30
$DServices.location        = New-Object System.Drawing.Point(4,25)
$DServices.Font            = New-Object System.Drawing.Font('Microsoft Sans Serif',12)
$DServices.BackColor           = [System.Drawing.ColorTranslator]::FromHtml("#ccc")

$DUWP                    = New-Object system.Windows.Forms.Button
$DUWP.text               = "Disable UWP Services"
$DUWP.width              = 203
$DUWP.height             = 30
$DUWP.location           = New-Object System.Drawing.Point(4,60)
$DUWP.Font               = New-Object System.Drawing.Font('Microsoft Sans Serif',12)
$DUWP.BackColor           = [System.Drawing.ColorTranslator]::FromHtml("#ccc")

$DUpdates                  = New-Object system.Windows.Forms.Button
$DUpdates.text             = "Disable Updates"
$DUpdates.width            = 205
$DUpdates.height           = 30
$DUpdates.location         = New-Object System.Drawing.Point(3,94)
$DUpdates.Font             = New-Object System.Drawing.Font('Microsoft Sans Serif',12)
$DUpdates.BackColor           = [System.Drawing.ColorTranslator]::FromHtml("#ccc")

$Form.controls.AddRange(@($Panel1,$Panel2,$ELabel,$DLabel))
$Panel1.controls.AddRange(@($EUpdates,$EUWP,$EServices))
$Panel2.controls.AddRange(@($DServices,$DUWP,$DUpdates))

$EServices.Add_Click({
    Write-Host "Enabling Services"
	Services Enable.reg
	Write-Host "Enabled Services"
})

$EUWP.Add_Click({
    Write-Host "Enabling UWP Services"
	chdir /d C:\Windows\System32
	ren RuntimeBroker.old RuntimeBroker.exe

	chdir /d C:\Windows\SystemApps\ShellExperienceHost_cw5n1h2txyewy
	ren ShellExperienceHost.old ShellExperienceHost.exe

	chdir /d C:\Windows\SystemApps\Microsoft.Windows.StartMenuExperienceHost_cw5n1h2txyewy
	ren StartMenuExperienceHost.old StartMenuExperienceHost.exe

	chdir /d C:\Windows\System32
	ren backgroundTaskHost.old backgroundTaskHost.exe

	chdir /d C:\Windows\System32
	ren CompPkgSrv.old CompPkgSrv.exe

	chdir /d C:\Windows\System32
	ren upfc.old upfc.exe
	Write-Host "Enabled UWP Services"
})

$EUpdates.Add_Click({
    Write-Host "Enabling Updates"
	RD /S /Q "%WinDir%\System32\GroupPolicyUsers"
	RD /S /Q "%WinDir%\System32\GroupPolicy"
	gpupdate /force
	Write-Host "Enabled Updates"
})
#Disable
$DServices.Add_Click({
    Write-Host "Disabling Services"
	Services Disable.reg
	Write-Host "Disabled Services"
})

$DUWP.Add_Click({
    Write-Host "Disabling UWP Services"
	chdir /d C:\Windows\System32
	ren RuntimeBroker.exe RuntimeBroker.old
	taskkill /F /FI "IMAGENAME eq RuntimeBroker.exe"

	chdir /d C:\Windows\SystemApps\ShellExperienceHost_cw5n1h2txyewy
	ren ShellExperienceHost.exe ShellExperienceHost.old
	taskkill /F /FI "IMAGENAME eq ShellExperienceHost.exe"

	chdir /d C:\Windows\SystemApps\Microsoft.Windows.StartMenuExperienceHost_cw5n1h2txyewy
	ren StartMenuExperienceHost.exe StartMenuExperienceHost.old
	taskkill /F /FI "IMAGENAME eq StartMenuExperienceHost.exe"

	chdir /d C:\Windows\System32
	ren backgroundTaskHost.exe backgroundTaskHost.old
	taskkill /F /FI "IMAGENAME eq backgroundTaskHost.exe"

	chdir /d C:\Windows\System32
	ren CompPkgSrv.exe CompPkgSrv.old
	taskkill /F /FI "IMAGENAME eq CompPkgSrv.exe"

	chdir /d C:\Windows\System32
	ren upfc.exe upfc.old
	taskkill /F /FI "IMAGENAME eq upfc.exe"

	chdir /d C:\Windows\SystemApps\Microsoft.Windows.Search_cw5n1h2txyewy
	ren SearchApp.exe SearchApp.old
	taskkill /F /FI "IMAGENAME eq SearchApp.exe"

	Write-Host "Disabled UWP Services"
})

$DUpdates.Add_Click({
    Write-Host "Disabling Updates"
	LGPO.exe /g "C:\WINDOWS\_Disable Updates\GPO"
	gpupdate /force
	Write-Host "Disabled Updates"
})

[void]$Form.ShowDialog()