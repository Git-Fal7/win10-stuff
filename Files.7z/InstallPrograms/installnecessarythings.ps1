Write-Host "Small script for installing stuff by Git-Fal7/Asterisks"
Write-Host "this installs chrome, 7zip, openshell and vlc using chocolately, then it removes chocolatey entirely from the computer"
Write-Host "the following is from the chocolately community packages site:"
Write-Host "Your use of the packages on this site means you understand they are not supported or guaranteed in any way. Due to the nature of a public repository and unreliability due to distribution rights, these packages should not be used as is for organizational purposes either."
Set-ExecutionPolicy Bypass -Scope Process -Force; .\install.ps1
Write-Host "chocolatey has been installed, installing everything"
choco install 7zip open-shell vlc googlechrome -y
Write-Host "installing VC++ dist and directx"
choco install vcredist-all directx -y
Remove-Item -Path C:\ProgramData\chocolatey -Recurse -Force